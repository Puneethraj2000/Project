<?php

define("from", "jobugo.online@gmail.com");
define("pass", "Jobugo123@#");

?>
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Fruit Selling Platform</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Amatic+SC:400,700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
</head>
  <body class="goto-here">
	
    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-light ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand text-success" href="index.php">Fruits</a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
	          <li class="nav-item active dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="dropdown04" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Shop</a>
              <div class="dropdown-menu" aria-labelledby="dropdown04">
              	<a class="dropdown-item" href="shop.php">Shop</a>
                <a class="dropdown-item" href="cart.php">Cart</a>
                <a class="dropdown-item" href="checkout.php">Checkout</a>
              </div>
            </li>
	          <li class="nav-item"><a href="about.php" class="nav-link">About</a></li>
	          <li class="nav-item"><a href="contact.php" class="nav-link">Contact</a></li>
	          <li class="nav-item cta cta-colored"><a href="my_cart.php" class="nav-link"><span class="icon-shopping_cart"></span>[0]</a></li>

	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->

    <div class="hero-wrap hero-bread" style="background-image: url('images/bg1.jpg');">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
          	<p class="breadcrumbs"><span class="mr-2"><a href="index.php">Home</a></span> <span>Products</span></p>
            <h1 class="mb-0 bread">Products</h1>
          </div>
        </div>
      </div>
    </div>

    <section class="ftco-section">
    	<div class="container">
    		<div class="row justify-content-center">
    			<div class="col-md-10 mb-5 text-center">
    				<ul class="product-category">
    					<li><a href="shop.php" class="active">Fruits</a></li>
    					
    				</ul>
    			</div>
    		</div>
    		<div class="row">
    			<div class="col-md-6 col-lg-3 ftco-animate">
				<form action="manageCart.php" method="POST">
    					<div class="product">
    						<a href="shop.php" class="img-prod"><img class="img-fluid" src="images/product_1.jpg" alt="Colorlib Template">
    							<div class="overlay"></div>
    								</a>
											<div class="text py-3 pb-4 px-3 text-center">
												<h3>Water Melon</h3>
													<div class="d-flex">
														<div class="pricing">
															<p class="price"><span class="mr-2 price-dc">$120.00</span><span class="price-sale">$80.00</span></p>
															<input type="hidden" name="Price" value="80">
														</div>
													</div>
											<div class="bottom-area d-flex px-3">
						<div class="m-auto d-flex">
											
								<button type="submit" class="btn btn-primary" name="AddToCart">
												Add to Cart
											</button>
											<input type="hidden" name="Price" value="80">
											<input type="hidden" name="Item_Name" value="Water Melon">
    					</div>
					
    			</div>
    		</div>
			</form>
    	</div>
    </div>
    			<div class="col-md-6 col-lg-3 ftco-animate">
				<form action="manageCart.php" method="POST">
    				<div class="product">
    					<a href="shop.php" class="img-prod"><img class="img-fluid" src="images/product-2.jpg" alt="Colorlib Template">
    						<div class="overlay"></div>
    					</a>
    					<div class="text py-3 pb-4 px-3 text-center">
    						<h3>Strawberry</h3>
    						<div class="d-flex">
    							<div class="pricing">
		    						<p class="price"><span>$120.00</span></p>
									<input type="hidden" name="Price" value="120">
		    					</div>
	    					</div>
    						<div class="bottom-area d-flex px-3">
	    						<div class="m-auto d-flex">
	    							
	    							<button type="submit" class="btn btn-primary" name="AddToCart">
												Add to Cart
											</button>
											<input type="hidden" name="Item_Name" value="Strawberry">
											<input type="hidden" name="Price" value="120">
    							</div>
    						</div>
    					</div>
    				</div>
</form>
    			</div>
    			<div class="col-md-6 col-lg-3 ftco-animate">
				<form action="manageCart.php" method="POST">
    				<div class="product">
    					<a href="shop.php" class="img-prod"><img class="img-fluid" src="images/product_3.jpg" alt="Colorlib Template">
	    					<div class="overlay"></div>
	    				</a>
    					<div class="text py-3 pb-4 px-3 text-center">
    						<h3>Kiwi</h3>
    						<div class="d-flex">
    							<div class="pricing">
		    						<p class="price"><span>$120.00</span></p>
									<input type="hidden" name="Price" value="120">
		    					</div>
	    					</div>
    						<div class="bottom-area d-flex px-3">
	    						<div class="m-auto d-flex">
	    							<button type="submit" class="btn btn-primary" name="AddToCart">
												Add to Cart
											</button>
											<input type="hidden" name="Price" value="120">
											<input type="hidden" name="Item_Name" value="Kiwi">
    							</div>
    						</div>
    					</div>
    				</div>
					</form>
    			</div>
    			<div class="col-md-6 col-lg-3 ftco-animate">
				<form action="manageCart.php" method="POST">
    				<div class="product">
    					<a href="shop.php" class="img-prod"><img class="img-fluid" src="images/product_4.jpg" alt="Colorlib Template">
    						<div class="overlay"></div>
    					</a>
    					<div class="text py-3 pb-4 px-3 text-center">
    						<h3>Orange</h3>
    						<div class="d-flex">
    							<div class="pricing">
		    						<p class="price"><span>$120.00</span></p>
									<input type="hidden" name="Price" value="120">
		    					</div>
	    					</div>
    						<div class="bottom-area d-flex px-3">
	    						<div class="m-auto d-flex">
	    							<button type="submit" class="btn btn-primary" name="AddToCart">
												Add to Cart
											</button>
											<input type="hidden" name="Item_Name" value="Orange">
											<input type="hidden" name="Price" value="120">
    							</div>
    						</div>
    					</div>
    				</div>
					</form>
    			</div>


    			<div class="col-md-6 col-lg-3 ftco-animate">
				<form action="manageCart.php" method="POST">
    				<div class="product">
    					<a href="shop.php" class="img-prod"><img class="img-fluid" src="images/product_5.jpg" alt="Colorlib Template">
    						<div class="overlay"></div>
    						
    					</a>
    					<div class="text py-3 pb-4 px-3 text-center">
    						<h3>Grapes</h3>
    						<div class="d-flex">
    							<div class="pricing">
		    						<p class="price"><span class="mr-2 price-dc">$120.00</span><span class="price-sale">$80.00</span></p>
									<input type="hidden" name="Price" value="80">
								</div>
	    					</div>
	    					<div class="bottom-area d-flex px-3">
	    						<div class="m-auto d-flex">
	    							
	    							<button type="submit" class="btn btn-primary" name="AddToCart">
												Add to Cart
											</button>
											<input type="hidden" name="Price" value="80">
											<input type="hidden" name="Item_Name" value="Grapes">
    							</div>
    						</div>
    					</div>
    				</div>
					</form>
    			</div>
    			<div class="col-md-6 col-lg-3 ftco-animate">
				<form action="manageCart.php" method="POST">
    				<div class="product">
    					<a href="shop.php" class="img-prod"><img class="img-fluid" src="images/product_6.jpg" alt="Colorlib Template">
    						<div class="overlay"></div>
    					</a>
    					<div class="text py-3 pb-4 px-3 text-center">
    						<h3>>Rambutan</h3>
    						<div class="d-flex">
    							<div class="pricing">
		    						<p class="price"><span>$120.00</span></p>
									<input type="hidden" name="Price" value="120">
		    					</div>
	    					</div>
    						<div class="bottom-area d-flex px-3">
	    						<div class="m-auto d-flex">
								<button type="submit" class="btn btn-primary" name="AddToCart">
												Add to Cart
											</button>
											<input type="hidden" name="Item_Name" value="Rambutan">
											<input type="hidden" name="Price" value="120">
    							</div>
    						</div>
    					</div>
    				</div>
					</form>
    			</div>
    			<div class="col-md-6 col-lg-3 ftco-animate">
				<form action="manageCart.php" method="POST">
    				<div class="product">
    					<a href="shop.php" class="img-prod"><img class="img-fluid" src="images/product_7.jpg" alt="Colorlib Template">
	    					<div class="overlay"></div>
	    				</a>
    					<div class="text py-3 pb-4 px-3 text-center">
    						<h3>Pineapple</h3>
    						<div class="d-flex">
    							<div class="pricing">
		    						<p class="price"><span>$120.00</span></p>
									<input type="hidden" name="Price" value="120">
		    					</div>
	    					</div>
    						<div class="bottom-area d-flex px-3">
	    						<div class="m-auto d-flex">
								<button type="submit" class="btn btn-primary" name="AddToCart">
												Add to Cart
											</button>
											<input type="hidden" name="Item_Name" value="Pineapple">
											<input type="hidden" name="Price" value="120">
    							</div>
    						</div>
    					</div>
    				</div>
					</form>
    			</div>
    			<div class="col-md-6 col-lg-3 ftco-animate">
				<form action="manageCart.php" method="POST">
    				<div class="product">
    					<a href="shop.php" class="img-prod"><img class="img-fluid" src="images/product_8.jpg" alt="Colorlib Template">
    						<div class="overlay"></div>
    					</a>
    					<div class="text py-3 pb-4 px-3 text-center">
    						<h3>Mango</h3>
    						<div class="d-flex">
    							<div class="pricing">
		    						<p class="price"><span>$120.00</span></p>
									<input type="hidden" name="Price" value="120">
		    					</div>
	    					</div>
    						<div class="bottom-area d-flex px-3">
	    						<div class="m-auto d-flex">
								<button type="submit" class="btn btn-primary" name="AddToCart">
									Add to Cart
											</button>
											<input type="hidden" name="Item_Name" value="Mango">
											<input type="hidden" name="Price" value="120">
    							</div>
    						</div>
    					</div>
    				</div>
					</form>
    			</div>

    			<div class="col-md-6 col-lg-3 ftco-animate">
				<form action="manageCart.php" method="POST">
    				<div class="product">
    					<a href="shop.php" class="img-prod"><img class="img-fluid" src="images/product_9.jpg" alt="Colorlib Template">
    					</a>
    					<div class="text py-3 pb-4 px-3 text-center">
    						<h3>Banana</h3>
							<input type="hidden" name="Item_Name" value="Banana">
    						<div class="d-flex">
    							<div class="pricing">
		    						<p class="price"><span class="mr-2 price-dc">$120.00</span><span class="price-sale">$80.00</span></p>
									<input type="hidden" name="Price" value="80">
								</div>
	    					</div>
	    					<div class="bottom-area d-flex px-3">
	    						<div class="m-auto d-flex">
								<button type="submit" class="btn btn-primary" name="AddToCart">
												Add to Cart
											</button>
											<input type="hidden" name="Price" value="80">
											<input type="hidden" name="Item_Name" value="Banana">
    							</div>
    						</div>
    					</div>
    				</div>
					</form>
    			</div>
    			<div class="col-md-6 col-lg-3 ftco-animate">
				<form action="manageCart.php" method="POST">
    				<div class="product">
    					<a href="shop.php" class="img-prod"><img class="img-fluid" src="images/product-10.jpg" alt="Colorlib Template">
    						<div class="overlay"></div>
    					</a>
    					<div class="text py-3 pb-4 px-3 text-center">
    						<h3>Apple</h3>
    						<div class="d-flex">
    							<div class="pricing">
		    						<p class="price"><span>$120.00</span></p>
									<input type="hidden" name="Price" value="120">
		    					</div>
	    					</div>
    						<div class="bottom-area d-flex px-3">
	    						<div class="m-auto d-flex">
								<button type="submit" class="btn btn-primary" name="AddToCart">
												Add to Cart
											</button>
											<input type="hidden" name="Item_Name" value="Apple">
											<input type="hidden" name="Price" value="120">
    							</div>
    						</div>
    					</div>
    				</div>
</form>
    			</div>
    			<div class="col-md-6 col-lg-3 ftco-animate">
				<form action="manageCart.php" method="POST">
    				<div class="product">
    					<a href="shop.php" class="img-prod"><img class="img-fluid" src="images/product_11.jpg" alt="Colorlib Template">
	    					<div class="overlay"></div>
	    				</a>
    					<div class="text py-3 pb-4 px-3 text-center">
    						<h3>Papaya</h3>
    						<div class="d-flex">
    							<div class="pricing">
		    						<p class="price"><span>$120.00</span></p>
									<input type="hidden" name="Price" value="120">
		    					</div>
	    					</div>
    						<div class="bottom-area d-flex px-3">
	    						<div class="m-auto d-flex">
								<button type="submit" class="btn btn-primary" name="AddToCart">
												Add to Cart
											</button>
											<input type="hidden" name="Item_Name" value="Papaya">
											<input type="hidden" name="Price" value="120">
    							</div>
    						</div>
    					</div>
    				</div>
</form>
    			</div>
    			<div class="col-md-6 col-lg-3 ftco-animate">
					<form action="manageCart.php" method="POST">
    				<div class="product">
    					<a href="shop.php" class="img-prod"><img class="img-fluid" src="images/product_12.jpg" alt="Colorlib Template">
    						<div class="overlay"></div>
    					</a>
    					<div class="text py-3 pb-4 px-3 text-center">
    						<h3>Pomegranate</h3>
    						<div class="d-flex">
    							<div class="pricing">
		    						<p class="price"><span>$120.00</span></p>
									<input type="hidden" name="Price" value="120">
		    					</div>
	    					</div>
    						<div class="bottom-area d-flex px-3">
	    						<div class="m-auto d-flex">
								<button type="submit" class="btn btn-primary" name="AddToCart">
												Add to Cart
											</button>
											<input type="hidden" name="Item_Name" value="Pomegranate">
											<input type="hidden" name="Price" value="120">
    							</div>
    						</div>
    					</div>
    				</div>
    			</div>
				<form>
    		</div>
    		
    	</div>
    </section>

		
    <footer class="ftco-footer ftco-section">
      <div class="container">
      	<div class="row">
      		<div class="mouse">
						<a href="shop.html" class="mouse-icon">
							<div class="mouse-wheel"><span class="ion-ios-arrow-up"></span></div>
						</a>
					</div>
      	</div>
        <div class="row">
          <div class="col-md-12 text-center">

			<p> Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart color-danger" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
						</p>
          </div>
        </div>
      </div>
    </footer>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>